package logging;

public class calculation {
	Double Interest(Double principle,Double rate,Double time)
	{
		Double si=(principle*rate*time)/100;
		return si;
	}

}
